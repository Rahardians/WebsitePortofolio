### Hi there!
### This is Simon Zirui Guo's personal website/portofolio.
### Access it through [simonguo.tech](http://simonguo.tech).
#### Contact Me at:
* [E-mail](simonguozirui@gmail.com)
* [LinkedIn](https://www.linkedin.com/in/simonguozirui/)

#### Framework used:
* Bootstrap CSS & JS
* Jquery
* Font Awesome
* Material Design

#### Hosted on:
* Github Pages

#### Further Development Plans
* Use Jekyll to generate sections from a json file of contents
* Faster load time
* Overall visual and style re-design
